from django.apps import AppConfig


class LoggerConfig(AppConfig):
    name = 'drf_api_logger'
    verbose_name = 'DRF API Logger'
